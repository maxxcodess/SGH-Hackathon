package androidx.versionedparcelable;

/* renamed from: androidx.versionedparcelable.R */
public final class C0549R {
    public C0549R() {
    }
}
