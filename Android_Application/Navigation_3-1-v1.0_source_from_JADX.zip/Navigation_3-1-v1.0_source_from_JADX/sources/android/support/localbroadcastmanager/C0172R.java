package android.support.localbroadcastmanager;

/* renamed from: android.support.localbroadcastmanager.R */
public final class C0172R {
    public C0172R() {
    }
}
